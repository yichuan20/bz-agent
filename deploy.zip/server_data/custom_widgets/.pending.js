const root = document.currentScript.parentElement;
root.style.cssText = 'height:100vh;overflow:hidden;background:var(--bg-primary);color:var(--text-primary);display:flex;flex-direction:column;padding:12px;box-sizing:border-box;';

root.innerHTML = `<div style="font-size:14px;font-weight:600;margin-bottom:8px;color:var(--text-primary)">Monthly Temperature (°C)</div><canvas id="tempChart"></canvas>`;

const s = document.createElement('script');
s.src = 'https://cdn.jsdelivr.net/npm/chart.js';
s.onload = () => {
  const ctx = root.querySelector('#tempChart');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
      datasets: [{
        label: 'Temperature (°C)',
        data: [3, 4, 8, 13, 17, 21, 24, 23, 19, 13, 7, 4],
        backgroundColor: 'rgba(59,130,246,0.7)',
        borderColor: 'rgba(59,130,246,1)',
        borderWidth: 1,
        borderRadius: 4,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: { ticks: { color: 'var(--text-secondary)' }, grid: { color: 'var(--border-primary)' } },
        y: { ticks: { color: 'var(--text-secondary)' }, grid: { color: 'var(--border-primary)' } }
      }
    }
  });
};
document.head.appendChild(s);
