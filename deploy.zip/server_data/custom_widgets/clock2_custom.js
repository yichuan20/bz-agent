document.body.style.cssText = 'margin:0;padding:0;';

const wrap = document.createElement('div');
wrap.style.cssText = `
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  height:100vh;overflow:hidden;
  background:var(--bg-primary);
  font-family:var(--font-heading,monospace);
  gap:0;
`;
document.body.appendChild(wrap);

const timeEl = document.createElement('div');
timeEl.style.cssText = `
  font-size:52px;font-weight:700;letter-spacing:2px;
  color:var(--text-primary);line-height:1;
`;

const dateEl = document.createElement('div');
dateEl.style.cssText = `
  font-size:14px;color:var(--text-secondary);letter-spacing:1px;margin-top:10px;
`;

const tzEl = document.createElement('div');
tzEl.style.cssText = `
  font-size:11px;color:var(--text-tertiary);margin-top:5px;letter-spacing:0.5px;
`;

wrap.appendChild(timeEl);
wrap.appendChild(dateEl);
wrap.appendChild(tzEl);

const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function pad(n){ return String(n).padStart(2,'0'); }

function tick(){
  const now = new Date();
  timeEl.textContent = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  dateEl.textContent = `${days[now.getDay()]}, ${months[now.getMonth()]} ${now.getDate()} ${now.getFullYear()}`;
  tzEl.textContent = Intl.DateTimeFormat().resolvedOptions().timeZone;
}

tick();
setInterval(tick, 1000);
